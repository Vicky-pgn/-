# 01 api 调用

1. 打开阿里云百炼，生成api_key
2. 阿里云百炼任意选择一个模型，进行部署
3. dify任意选择一个模型，进行部署,生成应用，拿到dify的API 密钥

# 02 code

1. 怎么跑前端+后端
2. debug

## 02 code step

1. 前端语言主要是vue,需要安装node js
2. 后端需要以下包等
   pip install uvicron
   uvicron(容器)
   pip install fastapi
   pip install dashscope
3. 拉前后端代码
4. 注册阿里云百炼,拿到api_key与app_id
5. 本地运行代码
6. 搜索arxive，任意拉一篇论文,作为知识库备用
