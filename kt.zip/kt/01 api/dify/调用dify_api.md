# 发布应用

1. 打开dify网址,登录注册
2. 导入文件 [00 documents\dify\dsl_文件\简易版的dsl.yml]
3. 切换知识库/切换模型/编辑workflow
4. 发布你的应用
5. 本地测试

# postman call dify应用

1. 点击你的应用
2. 点击访问api
   ![1739864951438](images/调用dify_api/1739864951438.png)
3. 查看相关文档
   ![1739865183609](images/调用dify_api/1739865183609.png)
4. 打开postman
5. 导入文档相关的命令
   修改body和headers![1739872915671](images/调用dify_api/1739872915671.png)
