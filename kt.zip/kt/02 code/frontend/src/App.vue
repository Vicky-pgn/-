<script setup>
import { ref, computed } from 'vue'
import page1 from './components/page1.vue'
import page2 from './components/page2.vue'

import HelloWorld from './components/HelloWorld.vue'
import TheWelcome from './components/TheWelcome.vue'

const routes = {
  '/': HelloWorld,
  '/about': TheWelcome,
  '/page1': page1,  
  '/page2':page2
}
const currentPath = ref(window.location.href)
window.addEventListener('hashchange', () => {
  currentPath.value = window.location.href
})
const currentView = computed(() => {
  var splits = currentPath.value.split('/')
  console.log(splits[splits.length - 1])
  // console.log(window.location.href)
  // console.log(currentPath.value.slice(1))
  return routes['/' + splits[splits.length - 1]]
})
</script>

<template style="height:100%">
    <component :is="currentView" />
</template>

<style scoped>

</style>
