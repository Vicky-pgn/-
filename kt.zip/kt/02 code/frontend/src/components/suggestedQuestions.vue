<template>
    <div style="width: 80%;background-color: #eee;margin-left: auto; margin-right: auto; border: #888 1px solid; font-size: 15px;padding: 5px;line-height: 2; ">
        <p style="font-family: pingFangSC_B;font-weight: 400;">
            小智整理了以下高频问题供你参考,</br>如果你的问题不在列表上，请直接在下方文本框,输入后咨询我噢₍ᐢ •⌄• ᐢ₎
        </p>

        <div style="background-color: #d0e5f0; color: #3a77f4; padding: 5px;line-height: 2.1;font-size: 18px;font-weight: 600; font-size: 15px;" @click="titleOnClick(option) " v-for="option in options" >
            <span> {{ option.title }}</span>
            <span class="icon svg-icon-wrap svg-ze svg-ze-ze-arrow-down-wrap" style="float: right;margin-right: 10px;"><svg xmlns="http://www.w3.org/2000/svg" class="styles__StyledSVGIconPathComponent-sc-4n1c4t-0 dauCNx svg-icon-path-icon fill" viewBox="0 0 32 32" width="18" height="18"><defs></defs><g :transform="option.showSubtitles? 'translate(30,30)rotate(180)' : ''"><path fill="#3a77f4" d="M15.811 23.47c-0.252-0.060-0.47-0.185-0.641-0.356l-10.685-10.685c-0.521-0.521-0.521-1.365 0-1.886s1.365-0.521 1.886 0l9.746 9.746 9.745-9.745c0.521-0.521 1.365-0.521 1.886 0s0.521 1.365 0 1.886l-10.685 10.685c-0.339 0.339-0.816 0.458-1.251 0.355z"></path></g></svg></span>
            <div @click="onQuestionClicked(subTitle)" v-if="option.showSubtitles" style="margin-left: 20px;" v-for="subTitle in option.subTitles">
                {{ subTitle }}
            </div>
        </div>
        
        
    </div>
</template>
<script>
    export default {
        props:{
            onQuestionClicked: {
                type: Function,
                required: true
            }
        },
        
        data() {
            return {
                options:
                    [
                        {
                            title: '标题1',
                            subTitles: [
                                '你会做什么',
                                '你是谁',
                                '我是谁'
                            ],
                            showSubtitles: false
                        },
                        {
                            title: '标题2',
                            subTitles: [
                                '你好',
                                '子标题2',
                                '子标题3'
                            ],
                            showSubtitles: false
                        },
                        {
                            title: '标题3',
                            subTitles: [
                                '子标题1',
                                '子标题2',
                                '子标题3'
                            ],
                            showSubtitles: false
                        }
                    ]
            };   
        },
        methods:{
            titleOnClick(option){
                option.showSubtitles = !option.showSubtitles;
            }
        }
    }
</script>