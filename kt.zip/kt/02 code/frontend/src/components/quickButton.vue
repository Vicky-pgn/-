<template>
    <div @click="onButtonClick" v-bind:style="{border:  '1px ' + color + ' solid', color: color}" style="width: 40px;height: 35px;padding-top: 5px; text-align: center; border-radius: 3px;">
        <img :src="getimageURL()" style="width: 12px; height: 12px;margin-top: 8px;margin-left: 1px; float: left;"/>

        <span style="font-size: 8px;float: right;width: 30px" v-html="text"></span> 
    </div>
</template>
<script>
    export default {
        
        data() {

        },
        props:{
            text: String,
            imageUrl: String,
            color:String,
            url: String
        },
        methods:{
            getimageURL(){
                return new URL(this.imageUrl, import.meta.url).href;
            },
            onButtonClick(){
                window.location.href = this.url;
            }

        }
    }
</script>