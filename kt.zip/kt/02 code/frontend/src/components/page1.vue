<script setup>

</script>

<template>
    <div style="margin-left: 10%;margin-right: 10%;margin-top: 20%">
        <div style="display: grid;">
            <div style="display: inline;">
                <label class="star">*</label>
                <label class="hintLabel">请输入邮箱</label>
            </div>
            <input class="defaultInput" id="email" type="input">
        </div>
        <div style="display: grid;margin-top: 5%">
            <div style="display: inline;">
                <label class="star">*</label>
                <label class="hintLabel">请输入验证码</label>
            </div>
            <div style="display: inline;">
                <input class="defaultInput" style="width: 60%;" id="captcha" type="input">
                <button class="defaultInput" id="captchaBtn"style="margin-left: 10%;width: 30%;">获取验证码</button>
            </div>
        </div>
        <div style="margin-top: 5%;">
            <input type="checkbox" style="height: 10px;">
            <label style="font-size: 10px; font-style: italic; color: #aaa">
                我已充分理解并且同意使用该产品及其相关服务。
            </label>
        </div>
        <div style="width: 100%;margin-top: 10%">
            <button type="button" style="float: right; width: 30%; background: #4095E5; border: none; color: #fff; height: 30px;">NEXT</button>
        </div>
    </div>
</template>


<style>
    .hintLabel{
        font-weight: 700;
    }
    .star{
        color: #f00;
        margin-right: 3px;
    }
    .defaultInput{
        background: #fff;
        border: solid 1px #4095E5;
        height: 25px;
    }
</style>