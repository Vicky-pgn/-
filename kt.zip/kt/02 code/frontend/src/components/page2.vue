<script setup>
  import quickButton from './quickButton.vue'
  import suggestedQuestions from './suggestedQuestions.vue';
</script>

<style>
  .quickButton{
    margin-left: 7px;
    margin-right: 7px; 
    display: flex;
  }
</style>

<template>
    <div style="width: 100%;padding-right: 10px;padding-left: 10px;padding-top: 30px;height: 15%; align-items: center;background: #f8f9fa;">
      <table style="width: 100%;">
        <tr>
        <td>
          <quickButton class="quickButton" text="一站式</br>搜索" imageUrl="../assets/search.png" color='#00f' url="http://www.baidu.com"/>
        </td>
        <td>
          <quickButton class="quickButton" text="热门</br>搜索" imageUrl="../assets/fire.png" color='#f00' url="http://www.sina.com"/>
        </td>
        <td>
          <quickButton class="quickButton" text="活动</br>广场" imageUrl="../assets/flag.png" color='#0a0' url="http://www.bing.com"/>
        </td>
        <td>
          <quickButton class="quickButton" text="客服与</br>帮助" imageUrl="../assets/helpdesk.png" color='#000' url="http://github.com"/>
        </td>
        </tr>
      </table>


    </div>
    <vue-advanced-chat
      ref="vac"
      style="height: 85%;"
      :current-user-id="currentUserId"
      :rooms="JSON.stringify(rooms)"
      :messages="JSON.stringify(messages)"
      :room-actions="JSON.stringify(roomActions)"
      :rooms-loaded="rooms_loaded"
      :messages-loaded= "messages_loaded_func"
      :single-room="true"
      :text-messages="JSON.stringify(text_messages)"
      @toggle-rooms-list="onToggleRoomsList()"
      @send-message="onSendMessage($event.detail[0])"
    >
      <div slot="room-header">
      </div>
      <div v-if="messages.length == 1" :slot="'message_-1'" style="position: absolute; left: 0%; right: 0%;">
        <suggestedQuestions :onQuestionClicked="sendMessageToAI"/>
      </div>

    
    </vue-advanced-chat>
    <!--
        <div style="position: fixed; z-index: 999; bottom: 0px; width: 100%;height: 60px;background: #EFEFEF;">
            <input v-model="userQuestion"/>
            <button @click="send">发送</button>
        </div>
      -->

</template>

<script>
import axios from 'axios';
import { register } from 'vue-advanced-chat'


register()

export default {

  data() {
    return {
      text_messages:{
        'CONVERSATION_STARTED': '欢迎使用小智在线',
      },
      userQuestion: '',
      rooms: [
              {
                roomId: '1',
                roomName: 'Room 1',
                avatar: 'assets/imgs/people.png',
                unreadCount: 4,
                index: 3,
                lastMessage: {
                  _id: 'zxy',
                  content: 'Last message received',
                  senderId: '1234',
                  username: 'John Doe',
                  timestamp: '10:20',
                  saved: true,
                  distributed: false,
                  seen: false,
                  new: true
                },
                users: [
                  {
                    _id: '1234',
                    username: 'John Doe',
                    avatar: 'assets/imgs/doe.png',
                    status: {
                      state: 'online',
                      lastChanged: 'today, 14:30'
                    }
                  },
                  {
                    _id: '4321',
                    username: 'John Snow',
                    avatar: 'assets/imgs/snow.png',
                    status: {
                      state: 'offline',
                      lastChanged: '14 July, 20:00'
                    }
                  }
                ],
                typingUsers: [ 4321 ]
              }
            ],
      messages: [
      ],
      rooms_loaded: true,
      messages_loaded_func: true,
      roomActions:[],
      currentUserId: 0
    }
  },

  methods: {
    sendMessageToAI(content){
      this.messages.push({
          _id: 0,
          content: content,
          senderId: '0',
          timestamp: 'July 04, 2024 at 1:00:00 PM',
          seen: true
        });
      this.message_loaded = false;
      let _this = this;
      axios({
        method: 'post',
        url: '/api/chat/',
        // headers: {
        //   'Authorization': 'Bearer app-U0rvsHx4PF3a9KS29LrcA0YX'
        // },
        params: {
            "question": content
        },
      }).then(function (response) {
          var answer = response.data.answer;
          console.log(answer);
          // console.log(getCurrentTime())
          _this.messages.push({
          _id: 0,
          content: answer,
          senderId: '1',
          timestamp: 'July 04, 2024 at 1:00:00 PM',
          seen: true
        });
        _this.message_loaded = true;

      });

    },
    onSendMessage({content,roomId,files,replyMessage}){
      this.sendMessageToAI(content);
    },

    onToggleRoomsList(){
      console.log('onToggleRoomsList')
      this.message_loaded = true
    },
    messages_loaded_func(){
      return true;
    },

    // Add the fucking custom style, or can't just simply override the css class on this shit!!
    addCustomStyle() {
      const style = document.createElement('style')
      style.textContent = `  .vac-app-border-b {
                        display: none !important;
                      }
                      .vac-col-messages .vac-container-scroll {
                        margin-top:0px;
                      }  
                      `
      this.$refs.vac.shadowRoot.appendChild(style)
    }
  },


  mounted() {
    setTimeout(() => {
      this.addCustomStyle();
      this.messages =  [
        {
          _id: -1,
          content: '欢迎使用ai聊天机器人',
          senderId: '-1',
          timestamp: 'December 11, 2019 at 4:00:00 PM',
          seen: true
        }
      ]
      this.roomsLoaded = true
      this.messages_loaded = true
      console.log(this.messages_loaded)
    }, 1000);

  }
}
</script>

<style scoped>

</style>