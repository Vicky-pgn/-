class BaseModel:
    def chat(prompt: str) -> str:
        raise NotImplemented