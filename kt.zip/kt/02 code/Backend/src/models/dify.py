import requests
import json

from src.models.baseModel import BaseModel

class DifyModel(BaseModel):
    def chat(self, prompt):
        url = "https://api.dify.ai/v1/chat-messages"

        payload = json.dumps({
            "inputs": {},
            "query": prompt,
            "response_mode": "blocking",
            "conversation_id": "",
            "user": "abc-123"
        })
        headers = {
            'Authorization': 'Bearer app-zpaIToIEpVv4uZQoRC9OjHfX',
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload, verify=False)
        return json.loads(response.text)['answer']
